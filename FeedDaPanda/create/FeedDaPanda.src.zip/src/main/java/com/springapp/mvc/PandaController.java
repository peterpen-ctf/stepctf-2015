package com.springapp.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;
import java.io.UnsupportedEncodingException;

@Controller
@RequestMapping("/")
public class PandaController {
    @RequestMapping(method = RequestMethod.GET)
    public String printWelcome(ModelMap model, HttpServletResponse response, @CookieValue(value = "login", defaultValue = "null") String cookie) {

        String notpandaB64 = null;
        String pandaB64 = null;

        try {
            notpandaB64 = DatatypeConverter.printBase64Binary("notpanda".getBytes("UTF-8"));
            pandaB64 = DatatypeConverter.printBase64Binary("panda".getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        if (cookie.equals("null")) {
            String empty = null;
            try {
                empty = DatatypeConverter.printBase64Binary("notpanda".getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            response.addCookie(new Cookie("login", empty));
            model.addAttribute("message", "Feed da panda");
            model.addAttribute("img", "/resources/img/1.jpg");
        } else if (cookie.equals(notpandaB64)) {
            model.addAttribute("message", "Feed da panda");
            model.addAttribute("img", "/resources/img/1.jpg");
        } else if (cookie.equals(pandaB64)) {
            response.addHeader("Dumplings", "STCTF#D0UL1K3C00K135GUYZ#");
            model.addAttribute("message", "Secret is in my dumplings");
            model.addAttribute("img", "/resources/img/2.jpg");
        } else {
            model.addAttribute("message", "Feed da panda");
            model.addAttribute("img", "/resources/img/1.jpg");
        }
        return "panda";
	}
}