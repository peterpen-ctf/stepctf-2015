package service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service for processing Users
 *
 */
@Service("userService")
@Transactional
public class UserService {

    protected static Logger logger = Logger.getLogger("service");

    @Resource(name="sessionFactory")
    private SessionFactory sessionFactory;

    public boolean auth(String login, String password) {
        logger.debug("user auth");

        if(more18(login) || more18(password)) {
            return false;
        }
        List result = new ArrayList();

            Session session = sessionFactory.getCurrentSession();
            String sql = "SELECT * FROM user WHERE login = '" + login + "' AND password = '" + password + "'";
            //^1' OR 1=1; -- $  ^' || 1 #$
            SQLQuery query = session.createSQLQuery(sql);

            result = query.list();

        return  !result.isEmpty();
    }

    private boolean more18(String str) {
        if (str.length() > 18) {
            return true;
        }
        return false;
    }
}