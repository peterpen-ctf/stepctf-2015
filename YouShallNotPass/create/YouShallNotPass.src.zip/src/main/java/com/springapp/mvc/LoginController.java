package com.springapp.mvc;

/**
 * Created by Patrick on 08.05.2015.
 */

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.HttpRequestHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import service.UserService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Controller
public class LoginController {

    protected static Logger logger = Logger.getLogger("controller");

    @Resource(name="userService")
    private UserService userService;

    @RequestMapping(value = "/YouShallPassHere", method = RequestMethod.GET)
    public String login(Model model) {
        model.addAttribute("message", "Hhmmm!");
        model.addAttribute("img", "/resources/img/1.gif");
        model.addAttribute("img_alt", "You shall no pass!");
        return "login";
    }

    @RequestMapping(value = "/YouShallPassHere/auth", method = RequestMethod.POST)
    public String auth(String login, String password,
                       HttpServletRequest request,
                       Model model) {

        logger.debug("Trying to login");

        boolean isExisted = userService.auth(login, password);
        if (isExisted) {
            model.addAttribute("message", "Welcome to Gandalf's backstage!<br>" +
                                          "You did it, boy.<br>");
            model.addAttribute("img", "/resources/img/3.jpg");
            model.addAttribute("img_alt", "Secret: STCTF#9anda1fHa5a10t0f53cr375#");
        } else {
            model.addAttribute("message", "Nooooooooope!");
            model.addAttribute("img", "/resources/img/1.gif");
            model.addAttribute("img_alt", "You shall no pass!");
        }
        return "login";
    }

}